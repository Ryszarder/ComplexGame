#pragma once

//These includes are specific to the wat we've set up GLFW and GLAD
#define GLFW_INCLUDE_NONE
#include "glfw3.h"
#include "glad.h"