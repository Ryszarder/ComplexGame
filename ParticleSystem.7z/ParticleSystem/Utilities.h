#pragma once

#include <string>

std::string LoadFileAsString(std::string filename);